<?php

session_start();
$_SESSION['email']=$_POST['email'];

echo "SUCCESSFUL!";

?>